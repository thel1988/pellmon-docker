./pellmonsrv -U pellmonsrv -C /etc/pellmon/pellmon.conf -D SYSTEM debug

