#! /usr/bin/python
# -*- coding: utf-8 -*-

# This is needed to find the local module scottecom
import os, sys
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from scottecom import scottecom
